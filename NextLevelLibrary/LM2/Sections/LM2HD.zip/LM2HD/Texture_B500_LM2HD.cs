﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Toolbox.Core;
using Toolbox.Core.Imaging;
using Toolbox.Core.IO;
using static NextLevelLibrary.LM3.TextureFormat;

namespace NextLevelLibrary
{
    public class TextureFormat_LM2HD : IFormat
    {
        public static Dictionary<uint, TextureFormat_LM2HD> TextureCache = new Dictionary<uint, TextureFormat_LM2HD>();

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public class Header
        {
            public uint ImageSize;
            public uint Hash;
            public uint Padding;
            public uint SamplerFlags = 87632;
            public ushort Width;
            public ushort Height;
            public ushort Depth;
            public byte ArrayCount = 1;
            public byte MipFlags; //4 bits, each is the mip count
            public uint Padding2;
        }

        public DDS TextureData;
        public Header header = new Header();

        private ChunkFileEntry File;

        public TextureFormat_LM2HD()
        {

        }

        public TextureFormat_LM2HD(ChunkFileEntry file)
        {
            this.File = file;

            var imageChunk = file.GetChild(ChunkType.TextureData);
            this.header = file.GetChild(ChunkType.TextureHeader).ReadStruct<Header>();

            //image data is DDS which is already supported
            TextureData = new DDS(imageChunk.Data);
            TextureData.LoadRenderableTexture();

            if (!TextureCache.ContainsKey(file.FilePath.Value))
                TextureCache.Add(file.FilePath.Value, this);
        }

        public void Import(string path, TexFormat format, uint mipCount = 10)
        {
            var image = Image.Load<Rgba32>(path);
            Import(image, format, mipCount);
        }

        public void Import(Image<Rgba32> image, TexFormat format, uint mipCount = 10)
        {
            var name_hash = this.header.Hash;

            var compressed_data = ImageHelper.Encode(image, mipCount, format);
            var width = image.Width;
            var height = image.Height;

            var swizzleHandler = new SwitchSwizzle(format);

            var header = new Header();
            header.Width = (ushort)width;
            header.Height = (ushort)height;
            header.ArrayCount = 1;
            header.Hash = name_hash;
            header.MipFlags = SetMipCount((byte)mipCount);

            this.TextureData = new DDS((uint)width, (uint)height, 1, format,
                new List<byte[]>() { compressed_data });
            TextureData.LoadRenderableTexture();

        }

        public void Dispose()
        {
            if (File != null && TextureCache.ContainsKey(File.FilePath.Value))
                TextureCache.Remove(File.FilePath.Value);

            TextureData.RenderableTex?.Dispose();
        }

        public void Save(ChunkEntry fileEntry)
        {
            header.Width = (ushort)TextureData.Width;
            header.Height = (ushort)TextureData.Height;
            header.Depth = 1;
            header.ArrayCount = 1;
            header.MipFlags = SetMipCount((byte)TextureData.MipCount);

            var imageChunk = fileEntry.GetChild(ChunkType.TextureData);
            var headerChunk = fileEntry.GetChild(ChunkType.TextureHeader);

            //write extra dds data
            TextureData.MainHeader.Reserved[9] = 1414813262; //NVTT magic
            if (TextureData.MainHeader.Reserved[10] == 0)
                TextureData.MainHeader.Reserved[10] = 131080; //unsure what this is, sampler info?

            var mem = new MemoryStream();
            TextureData.Save(mem);
            imageChunk.Data = new MemoryStream(mem.ToArray());

            header.ImageSize = (uint)imageChunk.Data.Length;
            headerChunk.WriteStruct(header);
        }

        private byte SetMipCount(byte count)
        {
            byte flag = 0x00; 
            flag |= count;
            flag |= (byte)(count << 4);
            return flag;
        }
    }
}
